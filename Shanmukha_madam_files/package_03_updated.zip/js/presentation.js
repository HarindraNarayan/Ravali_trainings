
window.onload = function () {
    if (document.location.hash != '') document.location = window.location.href.split('#')[0]
}

var basePath = "./";
if ((window.location.href).indexOf("https://") >= 0) {
    basePath = '/etc/designs/cf/canvas/content/cf-pharma/health-hcpportal/master/interactive/epresentation/cns-epilepsy/jcr:content/importer/';
}

var videos = [
    {
        type: 'video',
        title: 'logo',
        sources: [
            {
                src: 'https://videos.gskstatic.com/pharma/GSKpro/Global/MP4/cns_epilepsy_videos/logoAnimation.mp4',
                type: 'video/mp4'
            }
        ],
        poster: basePath + 'images/images/poster_imgs/video.jpg',
    },
    {
        type: 'video',
        title: 'intro',
        sources: [
            {
                src: 'https://videos.gskstatic.com/pharma/GSKpro/Global/MP4/cns_epilepsy_videos/video1_2.mp4',
                type: 'video/mp4'
            }
        ],
        poster: basePath + 'images/images/poster_imgs/video1.jpg',

    },
    {
        type: 'video',
        title: 'intro2',
        sources: [
            {
                src: 'https://videos.gskstatic.com/pharma/GSKpro/Global/MP4/cns_epilepsy_videos/video2.mp4',
                type: 'video/mp4'
            }
        ],
        poster: basePath + 'images/images/poster_imgs/video2.jpg',

    },
    {
        type: 'video',
        title: 'video3',
        sources: [
            {
                src: 'https://videos.gskstatic.com/pharma/GSKpro/Global/MP4/cns_epilepsy_videos/video3.mp4',
                type: 'video/mp4'
            }
        ],
        poster: basePath + 'images/images/poster_imgs/video3.jpg',

    },
    {
        type: 'video',
        title: 'video4',
        sources: [
            {
                src: 'https://videos.gskstatic.com/pharma/GSKpro/Global/MP4/cns_epilepsy_videos/video4.mp4',
                type: 'video/mp4'
            }
        ],
        poster: basePath + 'images/images/poster_imgs/video4.jpg',

    },
    {
        type: 'video',
        title: 'video5',
        sources: [
            {
                src: 'https://videos.gskstatic.com/pharma/GSKpro/Global/MP4/cns_epilepsy_videos/video5.mp4',
                type: 'video/mp4'
            }
        ],
        poster: basePath + 'images/images/poster_imgs/video5.jpg',

    },
    {
        type: 'video',
        title: 'video6',
        sources: [
            {
                src: 'https://videos.gskstatic.com/pharma/GSKpro/Global/MP4/cns_epilepsy_videos/video6.mp4',
                type: 'video/mp4'
            }
        ],
        poster: basePath + 'images/images/poster_imgs/video6.jpg',

    },
    {
        type: 'video',
        title: 'video7',
        sources: [
            {
                src: 'https://videos.gskstatic.com/pharma/GSKpro/Global/MP4/cns_epilepsy_videos/video7.mp4',
                type: 'video/mp4'
            }
        ],
        poster: basePath + 'images/images/poster_imgs/video7.jpg',

    },
    {
        type: 'video',
        title: 'video8',
        sources: [
            {
                src: 'https://videos.gskstatic.com/pharma/GSKpro/Global/MP4/cns_epilepsy_videos/video8.mp4',
                type: 'video/mp4'
            }
        ],
        poster: basePath + 'images/images/poster_imgs/video8.jpg',

    },
    {
        type: 'video',
        title: 'video9',
        sources: [
            {
                src: 'https://videos.gskstatic.com/pharma/GSKpro/Global/MP4/cns_epilepsy_videos/video9.mp4',
                type: 'video/mp4'
            }
        ],
        poster: basePath + 'images/images/poster_imgs/video9.jpg',

    },
    {
        type: 'video',
        title: 'video10',
        sources: [
            {
                src: 'https://videos.gskstatic.com/pharma/GSKpro/Global/MP4/cns_epilepsy_videos/video10.mp4',
                type: 'video/mp4'
            }
        ],
        poster: basePath + 'images/images/poster_imgs/video10.jpg',

    },
    {
        type: 'video',
        title: 'video11',
        sources: [
            {
                src: 'https://videos.gskstatic.com/pharma/GSKpro/Global/MP4/cns_epilepsy_videos/video11.mp4',
                type: 'video/mp4'
            }
        ],
        poster: basePath + 'images/images/poster_imgs/video11.jpg',

    },
    {
        type: 'video',
        title: 'video12',
        sources: [
            {
                src: 'https://videos.gskstatic.com/pharma/GSKpro/Global/MP4/cns_epilepsy_videos/video12.mp4',
                type: 'video/mp4'
            }
        ],
        poster: basePath + 'images/images/poster_imgs/video12.jpg',

    },
    {
        type: 'video',
        title: 'video13',
        sources: [
            {
                src: 'https://videos.gskstatic.com/pharma/GSKpro/Global/MP4/cns_epilepsy_videos/video13.mp4',
                type: 'video/mp4'
            }
        ],
        poster: basePath + 'images/images/poster_imgs/video13.jpg',

    },
    {
        type: 'video',
        title: 'video14',
        sources: [
            {
                src: 'https://videos.gskstatic.com/pharma/GSKpro/Global/MP4/cns_epilepsy_videos/video14.mp4',
                type: 'video/mp4'
            }
        ],
        poster: basePath + 'images/images/poster_imgs/video14.jpg',

    },
    {
        type: 'video',
        title: 'dummy',
        sources: [
            {
                src: 'https://videos.gskstatic.com/pharma/GSKpro/Global/MP4/cns_epilepsy_videos/logoAnimation.mp4',
                type: 'video/mp4'
            }
        ],
        poster: '',
    }
]
var score = {}, player1, player2, player3, player4, player5, player6, player7, player8, player9, player10, player11, player12, player13, player14;
var myScroll;
var counter = 0;
function selectOption(event) {
    let target = event.target;
    $(target).closest('.scene-wrapper').find('.descriptionBlock').removeClass('hidden').find('.' + target.getAttribute('data-target')).removeClass('hidden');
    $(target).closest('.scene-wrapper').find('.answersBlock').addClass('hidden');
    let scroll = target.getAttribute('data-scroll');
    if (scroll) {
        setTimeout(function () {
            myScroll = new IScroll('#' + scroll, {
                scrollbars: true,
                mouseWheel: true
            });

            myScroll.on('scrollStart', function () {
                $('body').addClass('noScroll')
            })
            myScroll.on('scrollEnd', function () {
                $('body').removeClass('noScroll')
            })

        }, 10);

    }

    let refTarget = $(target).closest('.slide').attr('id') + "_" + target.getAttribute('data-target');
    $('.references_block ol,.references_block .refTitle').addClass('hidden');
    // console.log($(target).closest('.slide').attr('id'));
    $('.' + refTarget).removeClass('hidden');
    $('.references_block .refTitle').removeClass('hidden');
    if (counter == 0) {
        score[$(target).closest('.scene-wrapper').find('.quesList').attr('data-quesNo')] = target.getAttribute('data-score');
        var val = Object.values(score).reduce(function (cur, prev) {
            return sum = Number(cur) + Number(prev);
        }, sum = 0);
        // console.log(val);
        !isNaN(val) ? $('.scoreVal').text(val) : $('.scoreVal').text(0);
    }
    if ($(target).attr("data-flag") == "false") {
        counter++;
    }
}
function tryAgain(event) {
    $(event.target).closest('.scene-wrapper').find('.descriptionBlock,.descriptionBlock>div').addClass('hidden');
    $(event.target).closest('.scene-wrapper').find('.answersBlock').removeClass('hidden');
    $('.references_block ol,.references_block .refTitle').addClass('hidden');
    setTimeout(function () { if (myScroll) myScroll.destroy(); }, 100);
    if (counter > 1) $(event.target).closest('.scene-wrapper').find('.answersBlock').find('li[data-flag="true"]').addClass('active');
};
function prevQuestion(event) {
    sessionStorage.setItem('prevQuestion', true);
    $(event.target).closest('.scene-wrapper').find('.questionWrapper').removeClass('hidden');
    $('.references_block ol, .references_block .refTitle').addClass('hidden');
    console.log(event.target);
    var curQues;
    if ($('.slide.active').find('.quesList').attr('data-quesno')) {
        curQues = Number($('.slide.active').find('.quesList').attr('data-quesno').split('question')[1]);
        var newScore = {}
        console.log(curQues);
        for (i = 0; i < curQues - 2; i++) {
            newScore[Object.keys(score)[i]] = score[Object.keys(score)[i]]
        }
        score = newScore;
    }
    else {
        delete score[Object.keys(score)[Object.keys(score).length - 1]];
    }
    var val = Object.values(score).reduce(function (cur, prev) {
        return sum = Number(cur) + Number(prev);
    }, sum = 0);
    !isNaN(val) ? $('.scoreVal').text(val) : $('.scoreVal').text(0);
    if (navigator.platform === 'iPad' || navigator.platform === 'MacIntel') {
        console.log('Prev audio');
        let audioFile = 'audio' + $(event.target).attr('data-go')
        setTimeout(function () { document.getElementById(audioFile).play(); }, 100);
    }

}
function selectMultiple(event) {
    let score = 0;
    $(event.target).closest('.answersBlock').find('.answer-btn').removeClass('hidden');
    $(event.target).toggleClass('active');
    $(event.target).closest('.quesList').find('.mulOption').each(function () {
        if ($(this).hasClass('active')) {
            score = score + Number($(this).attr('data-score'));
        }
    });
    $(event.target).closest('.answersBlock').find('.answer-btn').attr('data-score', score);
}
function continueFlow(cb) {

    $('.prevQuestion').addClass('events-none');
    $('.references_block ol,.references_block .refTitle').addClass('hidden');
    $('.plyr__control').removeClass('hidden')
    if (cb) {
        if (typeof cb == "function") cb();
        else if (typeof cb == "string") {

            if (navigator.platform === 'iPad' || navigator.platform === 'MacIntel') {
                if (cb) {
                    setTimeout(function () { document.getElementById(cb).play(); }, 10);
                }
            }
        }

    }
    setTimeout(function () { if (myScroll) myScroll.destroy(); }, 100);
    counter = 0;
}
function replayVideo(slideNo, playerId, videoId) {
    counter = 0;
    window["audio" + slideNo].pause();
    window["audio" + slideNo].currentTime = 0;
    $('.scene-' + slideNo).find('.questionWrapper').addClass('hidden');
    $('.scene-' + slideNo).find('.videoContainer').removeClass('hidden');
    $('.scene-' + slideNo).find('.questionWrapper li').removeClass('active');
    $('.references_block ol').addClass('hidden');
    playerId.source = videos[videoId];
    playerId.play();
}
function videoPlay(event, id) {
    window["player" + id].play();
    $(event.target).addClass('hidden');
}
function playerInit(playerId, videoId) {
    window[playerId] = new Plyr(videoId, {
        captions: { active: false },
        clickToPlay: false,
        autoplay: false,
        autopause: true,
        controls: [], fullscreen: { enabled: false }, keyboard: { focused: false, global: false }
    });
}
$(document).ready(function () {
    sessionStorage.setItem('prevQuestion', false);
    $('.references_block ol,.references_block .refTitle').addClass('hidden');
});
