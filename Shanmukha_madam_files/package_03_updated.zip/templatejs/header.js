$(document).ready(function() {
	
	/* Code for Including Header and Footer using AJAX. This code will run if the data-include="ajax" in the Header/footer include tag */
	var count = 0;
	var length = $('div[data-include="ajax"]').length;
		
	$('div[data-include="ajax"]').each( function(){
	  var includePath = $(this);
		$.ajax({
			type: "GET",
			cache: false,
			url: $(this).attr("data-include-path"),
			success: function (data) {
				$(includePath).append(data);
				count = count + 1;
				if (count == length){
					postInclude();
				}
			},
			dataType: 'html'
		});
	});

	
	function postInclude() {

		$(document).ready(function(){
	$('.navigation-left .navigation-item-title').each(function(){
		 if($(this).parent().hasClass('has-children')){
			 if(!$(this).parent().hasClass('navigation-level1')){
				 var x=$(this).html();
				 var i=x.indexOf("<");
				 if(i>0){
				 var y=x.substr(0, i-1);
				 var z=x.substr(i);
				 }
				 if(y.length>21){
				 $(this).css('max-height','82px');
				 }
				 var d="<span class='nav-text-dotted' style=' width: 85%; display: inline-block;'>"+y+"</span>"+z;
				 $(this).html(d);
				//$(this)..wrap("<span  style=' width: 85%; display: inline-block;'></span>");
			}
		}		
	});
    /*new fix for dotted leftnav*/
  if($(window).width() <= 768){
    $('.navigation-left .navigation-item .navigation-item-title').each(function(){
    //var fullText = jQuery(".navigation-left .navigation-item .navigation-item-title span.nav-text-dotted").text();console.log(fullText);
    var fullText = $(this).find("span.nav-text-dotted").text();
    var fullTextLength = fullText.length;console.log(fullTextLength);
    if (fullTextLength >= 36){
    var concatText = fullText.slice(0,36); console.log(concatText); 
    
    //var lastText = fullText.innerHTML = concatText + '...';
        //$(this).find("span.nav-text-dotted").html(lastText);
    //jQuery(".navigation-left .navigation-item .navigation-item-title span.nav-text-dotted").html(lastText);
    }
  });
  }
    /*END*/
		$("body").on("tap click", ".navigation .has-children > .navigation-item-title >" +
				" .navigation-item-decoration", function (event) {
			event.preventDefault();
			event.stopPropagation();

			var $this = $(this).closest(".has-children"),
				$siblings = $this.siblings(".has-children");

			$siblings.not($this).removeClass("is-open")
				.find(".has-children").removeClass("is-open");
			$this.toggleClass("is-open");
		});
	});

		$("<input type='button' name='nav-icon' class='nav-icon'>").insertAfter(".rte-header-banner p");
		$("<div class='hcpwebshop cartitem-mobile'></div>").insertAfter(".rte-header-banner .nav-icon");
		$(".hcpwebshop.cartitem-mobile").next("p").addClass("rte-menu-text-head");
		$(".logged-out a").wrapAll("<div class='nav-mobile'></div>");	
		$('.userbox-header .box-logged-in form.login-form').hide();
		$('.userbox-header .box-logged-in form.login-form').next('a').hide();
		$('.userbox-header .box-logged-in .login-links-password').hide();
		$('.userbox-header .box-logged-in .login-links-register').hide();
		$('.navigation-left ul.navigation-level1 li.navigation-item.is-active a').html();

		$(".logged-in p").click(function(){
			$(".box-logged-in").toggle('slow');
		});

		$('.rte-header-logged-in li a').each(function(index){
			var htmlContent = $(this).html();
			var url = $(this).attr('href');
			var title = $(this).attr('title');
			var ddSelect = "<a title='"+title+"' href='"+url+"'.html>"+htmlContent+"</a>";
			$('.userbox-header .logged-in').append(ddSelect);		
		});
		$('.userbox-header .logged-in form').insertAfter(".userbox-header .logged-in a:last");
		//$(".logged-in a,.logged-in form").wrapAll("<div class='box-logged-in'></div>");		

		if ($(".logged-in, .acc-logged-header .logged-in").is(":visible")) {		
		if($(".logged-in p .userBox-title").length > 0){
			if($(".logged-in p .userBox-title").text() == "Other"){
				$(".logged-in p .userBox-title").text($('.rte-header-others-metadata p').html());
				$(".logged-in p .userBox-lastName").empty();
				$(".logged-in p .userBox-firstName").empty();
			}
		}		
	}
		$(".nav-icon, .rte-menu-text, .rte-close-text").click(function(event){
		event.preventDefault();
		
		if ($(".logged-out").is(":visible")) { 
			$(".logged-out").slideUp('slow', function () {
				$(".human-icon").removeClass("nav-active");
				$('.rte-close-icon').hide();
				$(".box-header-secondary").slideToggle("slow");
				$(".nav-icon").toggleClass("nav-active");
					if($(".rte-header-banner .nav-icon").hasClass("nav-active")){
						$(".rte-menu-text-head .rte-close-text").css("display","block");
					}else{
						$(".rte-menu-text-head .rte-close-text").css("display","none");
					}
            });
		}
		else if ($(".acc-logged-header .logged-in").is(":visible")) {
			$(".logged-in").slideUp('slow', function () {
				$(".human-icon").removeClass("nav-active");
				$(".box-header-secondary").slideToggle("slow");
				$('.rte-close-icon').hide();
				$(".nav-icon").toggleClass("nav-active");
					if($(".rte-header-banner .nav-icon").hasClass("nav-active")){
						$(".rte-menu-text-head .rte-close-text").css("display","block");
					}else{
						$(".rte-menu-text-head .rte-close-text").css("display","none");
					}
            });
		}
		else
		{
			$(".box-header-secondary").slideToggle("slow");
			$(".nav-icon").toggleClass("nav-active");
				if($(".rte-header-banner .nav-icon").hasClass("nav-active")){
					$(".rte-menu-text-head .rte-close-text").css("display","block");
				}else{
					$(".rte-menu-text-head .rte-close-text").css("display","none");
				}
		}	

	});
	
	
	//////////////Left-Navigation
			$('.navigation-left ul li.navigation-level2 a.navigation-item-title').each(function(){
							var menuht = $(this).height();
							if(menuht == 20){
								$(this).css('max-height','62px');
							}else if(menuht == 40){
								$(this).css('max-height','82px');	
							}
							else if(menuht == 60){
								$(this).css('max-height','102px');	
							}
						});
	$(window).on('load', function(){
		leftnav_mob();
	});

		$(window).resize(function(){
		if($(window).width() > 767){
			$('.box-header-secondary').show();
			$(".rte-menu-text-head .rte-close-text").css("display","none");
			$(".logged-out").show();
			$(".rte-close-icon").hide();
			var id = $(this).attr('id');
        	var screen_width = $(window).width();
			$('.navigation-root').children('li').removeClass('is-active');
			$(this).parent('li').addClass('is-active');

		}else{
			if($('.box-header-secondary').is(':visible')){
				$(".rte-menu-text-head .rte-close-text").show();
				$(".rte-header-banner .nav-icon").addClass("nav-active");
			}
			/* $('.box-header-secondary').hide();
			$(".rte-header-banner .nav-icon").removeClass("nav-active");
			$(".rte-menu-text-head .rte-close-text").css("display","none");
			$(".logged-out").hide();
			$(".rte-close-icon").hide();
			$(".rte-header-banner .human-icon").removeClass("nav-active");*/
		}
		
		leftnav_mob();
	});

		$(".rte-header-banner p").after("<input type='button' name='human-icon' class='human-icon'>");

		$(".human-icon").click(function(event){
		event.preventDefault();
		
		if ($(".box-header-secondary").is(":visible")) {
			$(".box-header-secondary").slideUp('slow', function () {
				$(".nav-icon").removeClass("nav-active");
				$(".logged-out").slideToggle("slow");
				$('.rte-close-icon').toggle();
				$(".human-icon").toggleClass("nav-active");
				if($(".rte-header-banner .human-icon").hasClass("nav-active")){
					$(".rte-menu-text-head .rte-close-text").css("display","none");	
				}
			});
		}
		else
		{
			$(".logged-out").slideToggle("slow");
			$(".human-icon").toggleClass("nav-active");
			$('.rte-close-icon').toggle();
			if($(".rte-header-banner .human-icon").hasClass("nav-active")){
			$(".rte-menu-text-head .rte-close-icon").css("display","block");	
			}else{
				$(".rte-menu-text-head .rte-close-icon").css("display","none");
			}	
		}
	});
        
        
        
        
        $('.header-image').on('click', function(){
                    //Cog.Cookie.erase("befreheaderclick");
                                         var arr = $(this).parents('.Header-box').find('.richText');
                                         arr.hide();
                                        $(this).hide();
                                   		//$.Cookie.create("headerclick","0","true");

                                      console.log("asd");

                                                                }); 
                var rte= $('.Header-box').find('.richText');
                var img = $('.Header-box').find('.header-image');
                // if($("headerclick")){
                //     //Cog.Cookie.erase("befreheaderclick");
                //     console.log("gag00");
                //     $('.Header-box').find('.richText').css('display','block');
                //     $('.Header-box').find('.header-image').css('display','block');
                //       //var rte= $('.Header-box').find('.richText');
                //        rte.css('display','block');
                //      //var img = $('.Header-box').find('.header-image');
                //      img.css('display','block');
                // }
        
        
        
        
        
        
        
        

	$(".tabs-nav-list-select").change(function(){
            var selectedOption = $(this).find(":selected").text();
            $(this).next(".holder").text(selectedOption);
        }).trigger('change');

	$(".rte-go-to").after("<div class='rte-subheading-list'></div>");	

	$('.userbox-header .logged-in form').insertAfter(".userbox-header .logged-in a:last");

	$(".preview-url").hide();
	$('.access-gsk-urls').each(function(){
        var previewUrl = $(this).find('.preview-url').text(); 
        var windowsUrl = window.location.href; 
        var currentUrl = $(".richtext-access-gsk-master a").attr('href');
        var accessGskLink = "";
      if(windowsUrl.indexOf("uat") != -1){
         if(previewUrl == "$previewUrl" ){
			accessGskLink = currentUrl;
			}
			else{
			accessGskLink = previewUrl;
            }
		$(".richtext-access-gsk-master a").attr('href',accessGskLink);
	  }
	});

	if($(".userBox .logged-in").length>0){ 
    var logouttext = $(".userBox .logged-in button").first().text();
    var logoutredirectpath = $(".userBox .logged-in input[name='resource'][type='hidden']").val();                  
	var logoutbutton = '<form method="POST" action="/system/sling/logout"><input type="hidden" name="resource" value=' + logoutredirectpath + '><button type="submit" class="button">' + logouttext + '</button></form>';
    $(".richtext-access-gsk-master").hide();
	//$(".richtext-access-gsk-master a").remove();
    //$(".richtext-access-gsk-master p").html("");
	}
	if(!$(".richtext-access-gsk-master button").hasClass("access-logout") || !$(".userBox-homepage button").hasClass("access-logout") || !$(".userBox button").hasClass("access-logout")){
	$(".richtext-access-gsk-master button,.userBox-homepage button,.userBox button").click(function(){
		Cog.Cookie.erase('dmplogin');
	});
	}
	if($('.richtext-access-gsk-master').length > 0){               
	var dmpCookieVal = Cog.Cookie.read('dmplogin');
	if(dmpCookieVal==null || dmpCookieVal==""){
		$(".richtext-access-gsk-master button").addClass("access-logout");
		$(".userBox-homepage button").addClass("access-logout");
		$(".userBox button").addClass("access-logout");
		}
	}

    	$(".access-logout").click(function(){
                console.log("Log out click");
                window.open("http://access.gsk.com/selfservice/static/logout.jsp", "_blank" );
         });

    	$('.image-search-header').hover(function(){
		
		$(this).find('img').attr("src","/content/dam/global/hcpportal/master/search-hover.png");
		}, function() {
		$(this).find('img').attr("src", "/content/dam/global/hcpportal/master/search.png");
		});
			
		/*login icon change*/ /*pravin*/
		if($('.userbox-header .component-content div').hasClass("logged-out")){
			$(".human-icon").addClass("human-icon-loogedin");
		}
		else{
			$(".human-icon").removeClass("human-icon-loogedin");
			$(".human-icon").addClass("account-loogedin");
		}
		/************PLACEHOLDER********/
		
		
	var vwidth = $(document).width();
	//alert(vwidth);
	$(".no-border").parent().parent().parent().css("border","0 none");
	$(".multi-column-text").parent().addClass("multi-column-text-bg");

	if(vwidth<=767){
		if($(".userbox-header .component-content div").hasClass("logged-in")){
			$(".userbox-header").addClass("acc-logged-header");
		}
		else{
			$(".userbox-header").removeClass("acc-logged-header");	
		}
		$(".account-loogedin").click(function(){
			$(".acc-logged-header .logged-in").toggle('slow');
		});
	}

	$(".userBox .logged-in a,.userBox .logged-in form").wrapAll("<div class='box-logged-in'></div>");
		
		if($('.userBox .logged-in span.user').length > 0){
			$('.login form.login-form').show();
        }else{
			$('.login .logged-in form.login-form').hide();
        }
		/*END*/
		
		$("textarea").parent().css("max-height","465px");
	
		$(".login-links").insertBefore(".control-group");
		
		$('.rte-navigation-links-product span').each(function(){
			var className = $(this).attr('class');
			var anchorLink = $(this).find('a').attr('href');
			var anchorText = $(this).find('a').html();
			var appendString = '<li class="navigation-item navigation-level2 navigation-level2-green '+anchorText+'"><a class="navigation-item-title navigation-item-green" title="'+anchorText+'" href="'+anchorLink+'">'+anchorText+'<span class="navigation-item-decoration" tabindex="0"></span></a></li>';
			$('.navigation-left ul li.navigation-level1 ul.navigation-level2').append(appendString);
		});
		
		$('.rte-header-banner p a').each(function(){
			var anchorText = $(this).html();	
			var anchorLink = $(this).attr('href');
			var appendString = '<li class="navigation-item navigation-level1 navigation-level1-green '+anchorText+'"><a class="navigation-item-title navigation-item-green" title="Resources" href="'+anchorLink+'">'+anchorText+'<span class="navigation-item-decoration" tabindex="0"></span></a></li>';
			$('.navigation-horizontal ul.navigation-level1').append(appendString);
		});	
		/* Adding Basket link to mobile navigation */
		$('.rte-header-basket-metadata a').each(function(){
			var anchorText = $(this).text();	
			var anchorLink = $(this).attr('href');
			var appendString = '<li class="navigation-item navigation-level1 navigation-level1-basket '+anchorText+'"><a class="navigation-item-title navigation-item-basket" title="'+anchorText+'" href="'+anchorLink+'">'+anchorText+'<span class="navigation-item-decoration" tabindex="0"></span></a><span class="hcpwebshop cartitem-mobile-nav"></span></li>';
			$(appendString).insertAfter('.navigation-horizontal ul.navigation-level1 li.last.navigation-item.navigation-level1');
		});
		var startingPositionTop = 100; 
		$(".overlayContainer.box-events-sign-in").css("top", $(window).scrollTop() + parseInt(startingPositionTop, 10) + "px");
		$(".overlayContainer.box-events-registration").css("top", $(window).scrollTop() + parseInt(startingPositionTop, 10) + "px");

	};

	$(document).ready(function() {
	/* Left Navigation - List Addition - Start */
	if($(window).width() < 768){
		$('.box-left-navigation .content.paragraphSystem > div').each(function(index){
			$(this).addClass('left-navigator-'+index);
			if(($('.navigation-left ul li.first.navigation-item.navigation-level1 ul li').hasClass('navigation-level2'))){
				$('.navigation-left ul li.first.navigation-item.navigation-level1 ul.navigation-level2').append($(this).clone());
			}else{
				$('.navigation-left ul li.first.navigation-item.navigation-level1').append($(this).clone());
			}
		});
	$(".navigation-left .rte-left-nav-links").last().addClass('lastnav-link');
	$(".rte-left-nav-links .component-content").removeClass('rte-request-a-contact-head');
	$(".rte-left-nav-links .component-content").removeClass('rte-a-live-chat-head');
	}
	
	/*3.2.1 sitemap */
		$('.box-sitemap-content .sitemap .sitemap-column').each(function(e){
		$(this).find('ul').find('ul').find('ul').each(function(e){
			$(this).find('li').each(function(e){
				$(this).remove();
			});
        });
    }); 
	var showMoreText = $('.sitemap-sm').text();
	var showLessText = $('.sitemap-sl').text();
	$('.box-sitemap-content .sitemap .sitemap-column').each(function(e){
		$(this).children('ul').each(function(e){
		   var x=$(this).children('li').children('ul').children('li').length;
		   if(x>5){
			var count=0
			$(this).children('li').children('ul').children('li').each(function(e){
			count=count+1;
			if(count>5){
			     $(this).addClass('is-hidden');
			}	
			});
			$(this).append('<span class="rte-show-more-plus">'+showMoreText+'</span>');
			$(this).append('<span class="rte-show-more-plus showless" style="display : none">'+showLessText+'</span>');
			}
			
			$(this).append('<hr width="100%" class="divider-resources is-active" color="#f0efed" height="0.5px" style="margin-bottom:20px">');
        });
    });
	 
	 

	$('.rte-show-more-plus').click(function(e){	 
	    var x=$(this).parent().children('li').children('ul').children('li').length;
		var count=0;
		var totalCount=0;
		var activeCount=0;
		$(this).parent().children('li').children('ul').children('li').each(function(e){
		    totalCount=totalCount+1;
			if($(this).hasClass('is-hidden')){
				count=count+1;
			}
			else{
				activeCount=activeCount+1;
			}
		});
		

		if((activeCount==totalCount) && totalCount>=5){
			var showLess=0;
			$(this).parent().children('li').children('ul').children('li').each(function(e){
			showLess=showLess+1;
			
			if(showLess>5){
			$(this).addClass('is-hidden');
			}		
		});
		$(this).parent().find('span').each(function(e){
		  if($(this).hasClass('showless')){
		  $(this).css('display','none');
		  }
		  else{
		  $(this).show();
		  }
		  });
		}		
		
        var isActiveCount=x-count;
		
		if(!$(this).hasClass('showless')){
			if(true){
				var internalCount=0;

				$(this).parent().children('li').children('ul').children('li').each(function(e){
					internalCount=internalCount+1;
					if(true){
						$(this).removeClass('is-hidden');
					}
				});
				$(this).parent().find('span').each(function(e){
					if($(this).hasClass('showless')){
						$(this).css('display','block');
					}
					else{
						$(this).hide();
					}
				});				  
			}
		}
	});
});
if(length == 0 ){
		postInclude();
	}
	
	function leftnav_mob(){
	var screen_width = $(window).width();
	if(screen_width < 767){
		$('.rte-sub-nav-mobile').css("display","block");
		if($('.rte-sub-nav-mobile').length == 0)
		{
			$('.navigation-left').before("<div class='rte-sub-nav-mobile'><p><span class='sub-nav-mobile'></span></p></div>");
			
			var leftmenu = $('.sub-nav-mobile');
			var listmenu = $('.navigation-left');

			leftmenu.click(function() {
				
				listmenu.slideToggle(200);
	
			});
			
			var livetext = $('.navigation-left ul.navigation-level1 li.navigation-item.is-active a').html();
				$('.sub-nav-mobile').append(livetext);
			
			$(window).on('load', function(){
				
			});
		}
	}else if(screen_width > 767){
		$('.rte-sub-nav-mobile').css("display","none");
	}		
};


	//$('.header-image').on('click', function(){
//		//Cog.Cookie.erase("befreheaderclick");
//		   var arr = $(this).parents('.Header-box').find('.richText');
//		   arr.hide();
//		  $(this).hide();
//		  //$.Cookie.create("headerclick","0","true");
//
//		console.log("asd");
//		});

	$.ajax({
	url:"/content/cf-pharma/health-hcpportal/it_IT/hcp/home.userinfo.json",
	success : function(data){		 
		$(".lname").html(data.lastName);
		$(".fname").html(data.firstName);
		$(".email").html(data.email);
	}
	})
	

	
	
	
});	



